<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\cr;
use DB;

class cr extends Controller
{
     function add()
    {
    	return view('call');
	}
	function insert(Request $res)
	{
		$this->validate($res,[
			'name' => 'required|max:55',
			'email' => 'required|unique:cruds',
			'subject' => 'required|max:10',
			'message' => 'required|max:100',

		]);
		
		
		$ob=new Cr();
		$ob->name=$res->name;
		$ob->email=$res->email;
		$ob->email=$res->subject;
		$ob->email=$res->message;
		
		if($res->message)
		{
			$ob->save();
			return redirect('fetch');

		}
		else
		{
			echo"not save";
		}
	}
	 function fetch() 
		{ 
		//$use=crud::all();
		$use=DB::table('students')->select('id''name','email','subject','message')->get();
		return view('fetch',compact('use'));
	}
	function delete($id)
	{
		$use=crud::find($id);
		if($use->delete())
		{
			return redirect('/fetch')->with('msg',"record deleted");
		}
	}
	function edit($id)
	{
		$use=crud::find($id);
		return view("edit",compact('use'));
	}
	function editpost($id,request $res)
	{
			$image_name=rand().".".$res->file("att")->getClientOriginalName();
		//print_r($att);
		$ob=new Crud();
		$ob->name=$res->name;
		$ob->email=$res->email;
		$ob->image=$image_name;
		if($res->file("att")->move(public_path()."/upload/",$image_name))
		{
			$ob->save();
			return redirect('fetch')->with('msg',"record update");

		}
	}
}--}}
?>
}
