<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class t extends Controller
{
    function bloog()
    {
    	return view('blog');
    }
     function blog()
    {
    	return view('blogsingle');
    }
     function call()
    {
    	return view('call');
    }
    
     function cours()
    {
    	return view('course');
    }
     function courd()
    {
    	return view('coursedetail');
    }



     function gall()
    {
    	return view('gallery');
    }
 function indx()
    {
    	return view('index');

    }

 function mastr()
    {
    	return view('master');
    }
 function vido()
    {
    	return view('videos');
    }

    }
