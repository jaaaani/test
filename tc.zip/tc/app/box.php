<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class box extends Model
{
    //
}
