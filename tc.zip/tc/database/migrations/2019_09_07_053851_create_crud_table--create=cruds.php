<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCrudTableCreate=cruds extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        schema::create('cruds', function (Blueprint $table)){
            $table->bigIcreaments('id');
            $table->string('name',50);
             $table->string('email',30)->unique();
              $table->string('subject',100);
               $table->timestamps();


        });

        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        schema::dropIfExists('cruds');
    }
}
